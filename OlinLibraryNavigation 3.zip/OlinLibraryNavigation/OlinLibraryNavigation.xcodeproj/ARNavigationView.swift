//
//  ARNavigationView.swift
//  OlinLibraryNavigator
//
//  AR导航界面 - 显示AR相机和导航信息
//

import SwiftUI
import ARKit
import RealityKit

struct ARNavigationView: View {
    @ObservedObject var pathfinder: PathfindingViewModel
    @StateObject private var arViewModel: ARNavigationViewModel
    @Environment(\.presentationMode) var presentationMode
    
    init(pathfinder: PathfindingViewModel) {
        self.pathfinder = pathfinder
        _arViewModel = StateObject(wrappedValue: ARNavigationViewModel(pathfinder: pathfinder))
    }
    
    var body: some View {
        ZStack {
            // AR相机视图
            ARViewContainer(viewModel: arViewModel)
                .edgesIgnoringSafeArea(.all)
            
            // 覆盖UI
            VStack {
                // 顶部信息栏
                topInfoBar
                
                Spacer()
                
                // 底部说明
                bottomInstructions
            }
        }
        .navigationBarHidden(true)
    }
    
    // MARK: - 顶部信息栏
    private var topInfoBar: some View {
        VStack(spacing: 8) {
            HStack {
                // 关闭按钮
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 28))
                        .foregroundColor(.white)
                        .shadow(color: .black.opacity(0.3), radius: 3, x: 0, y: 2)
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 4) {
                    Text("AR导航")
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    if let distance = pathfinder.pathDistance {
                        Text("总距离: \(String(format: "%.1f", distance))米")
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.9))
                    }
                }
            }
            .padding(.horizontal)
            .padding(.top, 50)
            
            // 导航信息卡片
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("起点:")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                    Text(pathfinder.locationNames[pathfinder.startPoint] ?? "未知")
                        .font(.footnote)
                        .foregroundColor(.white)
                }
                
                Image(systemName: "arrow.right")
                    .foregroundColor(.white)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("终点:")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                    Text(pathfinder.locationNames[pathfinder.endPoint] ?? "未知")
                        .font(.footnote)
                        .foregroundColor(.white)
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.black.opacity(0.6))
                    .blur(radius: 10)
            )
            .padding(.horizontal)
        }
    }
    
    // MARK: - 底部说明
    private var bottomInstructions: some View {
        VStack(spacing: 12) {
            // AR初始化提示
            if !arViewModel.isARReady {
                HStack {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    Text("正在初始化AR...")
                        .font(.subheadline)
                        .foregroundColor(.white)
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.black.opacity(0.6))
                )
            } else {
                // 图例说明
                VStack(spacing: 8) {
                    HStack(spacing: 8) {
                        Circle()
                            .fill(Color.blue)
                            .frame(width: 12, height: 12)
                        Text("蓝色标记: 起点和终点")
                            .font(.caption)
                            .foregroundColor(.white)
                    }
                    
                    HStack(spacing: 8) {
                        Rectangle()
                            .fill(Color(red: 0.3, green: 0.7, blue: 1.0))
                            .frame(width: 20, height: 3)
                        Text("淡蓝色线条: 导航路径")
                            .font(.caption)
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.black.opacity(0.6))
                )
            }
            
            // 错误提示
            if let error = arViewModel.errorMessage {
                Text(error)
                    .font(.caption)
                    .foregroundColor(.red)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.white.opacity(0.9))
                    )
            }
            
            // 使用提示
            HStack {
                Image(systemName: "camera.fill")
                Text("保持手机垂直，相机朝前，高度约1.5米")
                    .font(.caption2)
            }
            .foregroundColor(.white.opacity(0.8))
            .padding(.horizontal)
            .padding(.bottom, 40)
        }
    }
}

// MARK: - ARView容器
struct ARViewContainer: UIViewRepresentable {
    let viewModel: ARNavigationViewModel
    
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        // 配置渲染
        arView.environment.lighting.intensityExponent = 1.5
        arView.renderOptions = [.disableDepthOfField, .disableMotionBlur]
        
        // 初始化AR
        viewModel.setupAR(arView: arView)
        
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {
        // 更新视图（如需要）
    }
    
    static func dismantleUIView(_ uiView: ARView, coordinator: ()) {
        uiView.session.pause()
    }
}

// MARK: - 预览
struct ARNavigationView_Previews: PreviewProvider {
    static var previews: some View {
        ARNavigationView(pathfinder: PathfindingViewModel())
    }
}
