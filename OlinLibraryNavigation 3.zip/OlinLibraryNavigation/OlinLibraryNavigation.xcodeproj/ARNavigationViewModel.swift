//
//  ARNavigationViewModel.swift
//  OlinLibraryNavigator
//
//  AR导航视图模型 - 管理AR会话和3D对象
//

import SwiftUI
import ARKit
import RealityKit
import Combine

class ARNavigationViewModel: NSObject, ObservableObject {
    @Published var isARReady = false
    @Published var errorMessage: String?
    
    let pathfinder: PathfindingViewModel
    var arView: ARView?
    
    init(pathfinder: PathfindingViewModel) {
        self.pathfinder = pathfinder
        super.init()
    }
    
    /// 初始化AR会话
    func setupAR(arView: ARView) {
        self.arView = arView
        
        // 配置AR会话
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        configuration.environmentTexturing = .automatic
        
        arView.session.run(configuration)
        arView.session.delegate = self
        
        // 添加引导覆盖层（仅真机）
        #if !targetEnvironment(simulator)
        let coachingOverlay = ARCoachingOverlayView()
        coachingOverlay.session = arView.session
        coachingOverlay.goal = .horizontalPlane
        coachingOverlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        arView.addSubview(coachingOverlay)
        #endif
        
        // 延迟后放置导航路径
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            self?.placeNavigationPath()
        }
    }
    
    /// 放置导航路径到AR场景
    private func placeNavigationPath() {
        guard let arView = arView else { return }
        
        // 转换2D路径到3D坐标
        let positions3D = convert2DPathTo3D()
        
        // 创建原点锚点
        let anchor = AnchorEntity(world: [0, 0, 0])
        arView.scene.addAnchor(anchor)
        
        // 创建起点标记
        if let startPos = positions3D.first {
            let startMarker = createTetrahedron(color: .blue, position: startPos)
            anchor.addChild(startMarker)
        }
        
        // 创建终点标记
        if let endPos = positions3D.last {
            let endMarker = createTetrahedron(color: .blue, position: endPos)
            anchor.addChild(endMarker)
        }
        
        // 创建路径线
        if positions3D.count > 1 {
            createPathLine(positions: positions3D, anchor: anchor)
        }
        
        isARReady = true
    }
    
    /// 将2D地图坐标转换为3D AR坐标
    private func convert2DPathTo3D() -> [SIMD3<Float>] {
        var result: [SIMD3<Float>] = []
        
        guard pathfinder.path.count > 1 else { return result }
        
        let metersPerPoint = Float(pathfinder.metersPerPoint)
        guard let startPoint = pathfinder.locations[pathfinder.path[0]] else { return result }
        
        for nodeId in pathfinder.path {
            guard let point2D = pathfinder.locations[nodeId] else { continue }
            
            // 计算相对起点的偏移
            let dx = Float(point2D.x - startPoint.x) * metersPerPoint
            let dz = Float(point2D.y - startPoint.y) * metersPerPoint
            
            // 映射到3D空间：X=左右，Y=高度(0)，Z=前后(取反)
            let position3D = SIMD3<Float>(dx, 0.0, -dz)
            result.append(position3D)
        }
        
        return result
    }
    
    /// 创建蓝色正四面体标记
    private func createTetrahedron(color: UIColor, position: SIMD3<Float>) -> ModelEntity {
        let mesh = ARGeometryHelper.createTetrahedronMesh(size: 0.3)
        let material = ARGeometryHelper.createMarkerMaterial(color: color)
        let model = ModelEntity(mesh: mesh, materials: [material])
        
        // 位置稍高于地面
        model.position = position + SIMD3<Float>(0, 0.15, 0)
        
        return model
    }
    
    /// 创建路径线段
    private func createPathLine(positions: [SIMD3<Float>], anchor: AnchorEntity) {
        guard positions.count > 1 else { return }
        
        let pathMaterial = ARGeometryHelper.createPathMaterial()
        
        // 连接每对相邻点
        for i in 0..<(positions.count - 1) {
            let start = positions[i]
            let end = positions[i + 1]
            
            let midpoint = (start + end) / 2
            let direction = end - start
            let distance = length(direction)
            
            // 创建线段（细长的盒子）
            let mesh = MeshResource.generateBox(width: 0.05, height: 0.02, depth: distance)
            let lineSegment = ModelEntity(mesh: mesh, materials: [pathMaterial])
            
            // 定位并旋转
            lineSegment.position = midpoint + SIMD3<Float>(0, 0.05, 0)
            let angle = atan2(direction.x, direction.z)
            lineSegment.orientation = simd_quatf(angle: -angle, axis: [0, 1, 0])
            
            anchor.addChild(lineSegment)
        }
        
        // 添加转角标记
        addCornerMarkers(positions: positions, anchor: anchor)
    }
    
    /// 在转角处添加球形标记
    private func addCornerMarkers(positions: [SIMD3<Float>], anchor: AnchorEntity) {
        guard positions.count > 2 else { return }
        
        for i in 1..<(positions.count - 1) {
            let pos = positions[i]
            let prev = positions[i - 1]
            let next = positions[i + 1]
            
            // 检查是否为显著转角
            if ARGeometryHelper.isSignificantCorner(previous: prev, current: pos, next: next) {
                let mesh = MeshResource.generateSphere(radius: 0.08)
                var material = SimpleMaterial()
                material.color = .init(tint: UIColor(red: 0.5, green: 0.8, blue: 1.0, alpha: 0.8))
                
                let marker = ModelEntity(mesh: mesh, materials: [material])
                marker.position = pos + SIMD3<Float>(0, 0.05, 0)
                
                anchor.addChild(marker)
            }
        }
    }
}

// MARK: - ARSessionDelegate
extension ARNavigationViewModel: ARSessionDelegate {
    func session(_ session: ARSession, didFailWithError error: Error) {
        DispatchQueue.main.async { [weak self] in
            self?.errorMessage = "AR会话失败: \(error.localizedDescription)"
        }
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        DispatchQueue.main.async { [weak self] in
            self?.errorMessage = "AR会话被中断"
        }
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        DispatchQueue.main.async { [weak self] in
            self?.errorMessage = nil
        }
    }
}
