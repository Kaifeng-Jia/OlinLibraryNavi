//
//  ARGeometryHelper.swift
//  OlinLibraryNavigator
//
//  AR几何体辅助类 - 用于创建3D形状和计算
//

import Foundation
import RealityKit
import simd

/// 辅助类：创建AR导航所需的3D几何体
class ARGeometryHelper {
    
    /// 创建正四面体网格
    /// - Parameter size: 边长（米）
    /// - Returns: 正四面体的MeshResource
    static func createTetrahedronMesh(size: Float = 0.3) -> MeshResource {
        // 正四面体的顶点位置
        let height = size * sqrt(2.0/3.0)
        let radius = size * sqrt(3.0) / 3.0
        
        // 4个顶点
        let vertices: [SIMD3<Float>] = [
            SIMD3<Float>(0, -height/3, radius),                    // 前
            SIMD3<Float>(-size/2, -height/3, -radius/2),          // 左后
            SIMD3<Float>(size/2, -height/3, -radius/2),           // 右后
            SIMD3<Float>(0, height * 2/3, 0)                       // 顶点
        ]
        
        // 4个三角面（逆时针）
        let indices: [UInt32] = [
            0, 2, 1,  // 底面
            0, 1, 3,  // 侧面1
            1, 2, 3,  // 侧面2
            2, 0, 3   // 侧面3
        ]
        
        // 计算法线
        var normals: [SIMD3<Float>] = []
        for vertex in vertices {
            normals.append(normalize(vertex))
        }
        
        // 创建网格描述符
        var descriptor = MeshDescriptor(name: "tetrahedron")
        descriptor.positions = MeshBuffer(vertices)
        descriptor.normals = MeshBuffer(normals)
        descriptor.primitives = .triangles(indices)
        
        return try! MeshResource.generate(from: [descriptor])
    }
    
    /// 创建路径材质（淡蓝色）
    static func createPathMaterial() -> SimpleMaterial {
        var material = SimpleMaterial()
        material.color = .init(tint: UIColor(red: 0.3, green: 0.7, blue: 1.0, alpha: 0.7))
        material.roughness = .float(0.5)
        material.metallic = .float(0.0)
        return material
    }
    
    /// 创建标记材质（蓝色）
    static func createMarkerMaterial(color: UIColor) -> SimpleMaterial {
        var material = SimpleMaterial()
        material.color = .init(tint: color)
        material.roughness = .float(0.2)
        material.metallic = .float(0.1)
        return material
    }
    
    /// 判断是否为显著的转角
    static func isSignificantCorner(previous: SIMD3<Float>, current: SIMD3<Float>, next: SIMD3<Float>, minimumAngle: Float = 0.26) -> Bool {
        let dir1 = normalize(current - previous)
        let dir2 = normalize(next - current)
        
        let dotProduct = dot(dir1, dir2)
        let angle = acos(max(-1.0, min(1.0, dotProduct)))
        
        return angle > minimumAngle // ~15度
    }
}
