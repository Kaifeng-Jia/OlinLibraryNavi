# 配置指南

## 项目配置步骤

### 1. 添加相机权限到 Info.plist

在你的项目中找到 `Info.plist` 文件，添加以下键值对：

**方法一：使用 Xcode 的 Info.plist 编辑器**

1. 在项目导航器中找到 `Info.plist`
2. 右键点击空白处，选择 "Add Row"
3. 添加以下条目：

| Key | Type | Value |
|-----|------|-------|
| Privacy - Camera Usage Description | String | 需要使用相机来提供AR导航功能 |
| Privacy - Location When In Use Usage Description | String | 需要访问位置信息以提供更准确的AR导航 |

**方法二：直接编辑 XML（如果以源代码方式打开）**

```xml
<dict>
    <!-- 其他已有的键值对 -->
    
    <key>NSCameraUsageDescription</key>
    <string>需要使用相机来提供AR导航功能</string>
    
    <key>NSLocationWhenInUseUsageDescription</key>
    <string>需要访问位置信息以提供更准确的AR导航</string>
    
    <!-- ARKit 设备能力 -->
    <key>UIRequiredDeviceCapabilities</key>
    <array>
        <string>arkit</string>
    </array>
</dict>
```

### 2. 确保框架已链接

在 **Target Settings → General → Frameworks, Libraries, and Embedded Content** 中，确保包含：

- ✅ ARKit.framework
- ✅ RealityKit.framework
- ✅ SwiftUI.framework

这些框架通常会自动链接，但如果遇到编译错误，请手动添加。

### 3. 设置部署目标

- 最低 iOS 版本：**iOS 13.0** 或更高
- 在 **Target Settings → General → Deployment Info** 中设置

### 4. 配置签名

- 在 **Target Settings → Signing & Capabilities** 中
- 选择你的开发团队
- 启用 "Automatically manage signing"

### 5. 测试设备要求

⚠️ **重要提醒**：

- ARKit **不支持模拟器**，必须在真实设备上测试
- 支持的设备：iPhone 6s 或更新的机型
- iPad（第5代）或更新的机型
- 需要良好的光照条件

## 编译和运行

1. 连接支持 ARKit 的 iOS 设备
2. 在 Xcode 中选择你的设备作为目标
3. 点击 Run (⌘R) 编译并运行
4. 首次运行时，会请求相机权限，请点击"允许"

## 使用流程

1. **选择起点和终点**
   - 在"From"字段输入起点编号（如：1）
   - 在"To"字段输入终点编号（如：35）

2. **计算路径**
   - 点击"Find Path"按钮
   - 查看计算出的距离和2D地图上的路径

3. **启动 AR 导航**
   - 点击"Start AR Navigation"按钮
   - 进入 AR 视图

4. **在 AR 中导航**
   - 保持手机垂直，摄像头对准前方
   - 慢慢移动手机，让 ARKit 识别环境
   - 等待蓝色标记和路径线出现
   - 蓝色正四面体标记起点和终点
   - 淡蓝色线条显示导航路径

## 故障排除

### 编译错误

**错误：`Cannot find 'ARView' in scope`**
- 解决：确保导入了 `import RealityKit`

**错误：`Use of undeclared type 'ARWorldTrackingConfiguration'`**
- 解决：确保导入了 `import ARKit`

### 运行时问题

**相机权限被拒绝**
- 在 iOS 设置 → 隐私 → 相机 中，开启应用的相机权限
- 重新启动应用

**AR 无法初始化**
- 确保在真实设备上运行（不是模拟器）
- 确保光照充足
- 尝试在不同的环境中测试

**路径不显示或位置不对**
- 移动手机以帮助 AR 建立空间定位
- 等待几秒钟让 AR 完全初始化
- 确保在第一部分正确计算了路径

**性能问题**
- 关闭其他占用相机的应用
- 确保 iOS 系统是最新版本
- 在设置中清理手机存储空间

## 技术支持

如果遇到其他问题，请检查：

1. Xcode 控制台的错误消息
2. 设备日志（Window → Devices and Simulators → 选择设备 → View Device Logs）
3. 确保所有代码文件都已添加到项目 target

## 文件清单

确保以下文件都在你的项目中：

- ✅ `PathfindingViewModel.swift` (已修改)
- ✅ `ContentView.swift` (已修改)
- ✅ `ARNavigationViewModel.swift` (新增)
- ✅ `ARNavigationView.swift` (新增)
- ✅ `ARGeometryHelper.swift` (新增)
- ✅ `OlinLibraryNavigatorApp.swift` (已有)

## 下一步优化建议

完成基本功能后，可以考虑：

1. 添加实时位置追踪
2. 添加语音导航提示
3. 添加距离下一个转角的提示
4. 优化 AR 锚点的放置
5. 添加路径重新计算功能
6. 支持保存和加载 AR 会话

---

祝开发顺利！🚀
