import SwiftUI

struct ContentView: View {
    @StateObject private var pathfinder = PathfindingViewModel()
    @FocusState private var isInputFocused: Bool
    @State private var showARNavigation = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Input section
                VStack(spacing: 12) {
                    HStack {
                        Text("From:")
                            .font(.headline)
                            .frame(width: 60, alignment: .leading)
                        TextField("Location", text: Binding(
                            get: { String(pathfinder.startPoint) },
                            set: { pathfinder.startPoint = Int($0) ?? 1 }
                        ))
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numberPad)
                    }
                    
                    if let name = pathfinder.locationNames[pathfinder.startPoint] {
                        Text(name)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("To:")
                            .font(.headline)
                            .frame(width: 60, alignment: .leading)
                        TextField("Location", text: Binding(
                            get: { String(pathfinder.endPoint) },
                            set: { pathfinder.endPoint = Int($0) ?? 35 }
                        ))
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numberPad)
                    }
                    
                    if let name = pathfinder.locationNames[pathfinder.endPoint] {
                        Text(name)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Button(action: {
                        pathfinder.calculatePath()
                    }) {
                        Text("Find Path")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    
                    if let distance = pathfinder.pathDistance {
                        Text("Distance: \(String(format: "%.1f", distance))m")
                            .font(.subheadline)
                            .foregroundColor(.green)
                    }
                    
                    if let error = pathfinder.errorMessage {
                        Text(error)
                            .font(.caption)
                            .foregroundColor(.red)
                    }
                    
                    // AR Navigation Button
                    if !pathfinder.path.isEmpty {
                        NavigationLink(destination: ARNavigationView(pathfinder: pathfinder), isActive: $showARNavigation) {
                            Button(action: {
                                showARNavigation = true
                            }) {
                                HStack {
                                    Image(systemName: "arkit")
                                    Text("Start AR Navigation")
                                }
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(Color.green)
                                .cornerRadius(10)
                            }
                        }
                    }
                }
                .padding()
                .background(Color(red: 0.95, green: 0.95, blue: 0.97))
                
                Divider()
                
                // Map area - fully auto-scaled to fit screen
                MapView(pathfinder: pathfinder)
            }
            .navigationTitle("Olin Library Floor 3")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct MapView: View {
    @ObservedObject var pathfinder: PathfindingViewModel
    
    var body: some View {
        GeometryReader { geometry in
            let mapWidth: CGFloat = 600
            let mapHeight: CGFloat = 1250
            
            // Calculate scale to fit the entire map in available space
            let scaleW = geometry.size.width / mapWidth
            let scaleH = geometry.size.height / mapHeight
            let scale = min(scaleW, scaleH)
            
            ZStack {
                Color.white.ignoresSafeArea()
                
                ZStack {
                    // Structure
                    StructureView()
                    
                    // Points
                    ForEach(pathfinder.locations.keys.sorted(), id: \.self) { id in
                        if let pos = pathfinder.locations[id] {
                            PointView(
                                id: id,
                                position: pos,
                                isStart: pathfinder.startPoint == id,
                                isEnd: pathfinder.endPoint == id,
                                isOnPath: pathfinder.path.contains(id)
                            )
                        }
                    }
                    
                    // Path
                    if pathfinder.path.count > 1 {
                        PathView(path: pathfinder.path, locations: pathfinder.locations)
                    }
                }
                .frame(width: mapWidth, height: mapHeight)
                .scaleEffect(scale)
                .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
            }
        }
    }
}

struct StructureView: View {
    var body: some View {
        ZStack {
            // Outer border
            Rectangle()
                .stroke(Color.black, lineWidth: 3)
                .frame(width: 560, height: 1210)
                .position(x: 300, y: 625)
            
            // Left book stacks (gray areas)
            Rectangle()
                .fill(Color.gray.opacity(0.25))
                .frame(width: 165, height: 180)
                .position(x: 200, y: 150)
            
            Rectangle()
                .fill(Color.gray.opacity(0.25))
                .frame(width: 165, height: 260)
                .position(x: 200, y: 360)
            
            Rectangle()
                .fill(Color.gray.opacity(0.25))
                .frame(width: 165, height: 450)
                .position(x: 200, y: 705)
            
            Rectangle()
                .fill(Color.gray.opacity(0.25))
                .frame(width: 165, height: 180)
                .position(x: 200, y: 1020)
            
            // Right book stacks
            Rectangle()
                .fill(Color.gray.opacity(0.25))
                .frame(width: 175, height: 240)
                .position(x: 415, y: 195)
            
            Rectangle()
                .fill(Color.gray.opacity(0.25))
                .frame(width: 175, height: 320)
                .position(x: 415, y: 490)
            
            Rectangle()
                .fill(Color.gray.opacity(0.25))
                .frame(width: 175, height: 300)
                .position(x: 415, y: 820)
            
            // Central stairwell
            Rectangle()
                .stroke(Color.black, lineWidth: 2)
                .frame(width: 70, height: 95)
                .position(x: 260, y: 220)
            
            Image(systemName: "stairs")
                .font(.system(size: 16))
                .position(x: 260, y: 220)
            
            Text("Stairs")
                .font(.system(size: 9))
                .position(x: 260, y: 245)
            
            // Bottom left stairwell
            Rectangle()
                .stroke(Color.black, lineWidth: 2)
                .frame(width: 70, height: 90)
                .position(x: 210, y: 1060)
            
            Image(systemName: "stairs")
                .font(.system(size: 16))
                .position(x: 210, y: 1060)
            
            // Bottom facilities
            Rectangle()
                .stroke(Color.black, lineWidth: 2)
                .frame(width: 90, height: 85)
                .position(x: 380, y: 1045)
            
            HStack(spacing: 5) {
                VStack(spacing: 2) {
                    Image(systemName: "figure.stand")
                        .font(.system(size: 14))
                    Text("M")
                        .font(.system(size: 8))
                }
                VStack(spacing: 2) {
                    Image(systemName: "figure.stand.dress")
                        .font(.system(size: 14))
                    Text("W")
                        .font(.system(size: 8))
                }
            }
            .position(x: 380, y: 1050)
            
            // Study rooms (bottom)
            Text("Study Rooms")
                .font(.system(size: 10))
                .foregroundColor(.blue)
                .position(x: 330, y: 1150)
            
            // Labels
            Text("Graduate & Faculty Reading Rooms")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(.gray)
                .position(x: 300, y: 25)
            
            Text("Book Stacks")
                .font(.system(size: 9))
                .foregroundColor(.gray)
                .position(x: 200, y: 100)
            
            Text("Book Stacks")
                .font(.system(size: 9))
                .foregroundColor(.gray)
                .position(x: 415, y: 100)
        }
    }
}

struct PointView: View {
    let id: Int
    let position: CGPoint
    let isStart: Bool
    let isEnd: Bool
    let isOnPath: Bool
    
    var body: some View {
        ZStack {
            Circle()
                .fill(color)
                .frame(width: 22, height: 22)
            
            if isStart || isEnd {
                Circle()
                    .stroke(Color.yellow, lineWidth: 2)
                    .frame(width: 26, height: 26)
            }
            
            Text("\(id)")
                .font(.system(size: 8, weight: .bold))
                .foregroundColor(.white)
        }
        .position(position)
    }
    
    var color: Color {
        if isStart { return .green }
        if isEnd { return .red }
        if isOnPath { return .orange }
        return Color(red: 0.7, green: 0.1, blue: 0.1)
    }
}

struct PathView: View {
    let path: [Int]
    let locations: [Int: CGPoint]
    
    var body: some View {
        ZStack {
            Path { p in
                guard path.count > 0 else { return }
                guard let first = locations[path[0]] else { return }
                p.move(to: first)
                
                for i in 1..<path.count {
                    if let point = locations[path[i]] {
                        p.addLine(to: point)
                    }
                }
            }
            .stroke(Color.blue, style: StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))
            
            // Arrows
            ForEach(Array(path.indices.dropLast()), id: \.self) { i in
                if let start = locations[path[i]], let end = locations[path[i + 1]] {
                    ArrowView(start: start, end: end)
                }
            }
        }
    }
}

struct ArrowView: View {
    let start: CGPoint
    let end: CGPoint
    
    var body: some View {
        let angle = atan2(end.y - start.y, end.x - start.x)
        let mid = CGPoint(x: (start.x + end.x) / 2, y: (start.y + end.y) / 2)
        
        Image(systemName: "arrowtriangle.forward.fill")
            .font(.system(size: 12))
            .foregroundColor(.blue)
            .rotationEffect(.radians(angle))
            .position(mid)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
