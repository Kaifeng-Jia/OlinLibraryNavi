# AR Navigation Setup Instructions

## 完成的功能

已经成功实现了以下功能：

1. ✅ 在原有UI中添加了"Start AR Navigation"按钮
2. ✅ 实现了ARKit的SLAM功能
3. ✅ 在AR视图中用蓝色正四面体（锥体）标记起点和终点
4. ✅ 使用正确的现实世界距离比例（基于metersPerPoint计算）
5. ✅ 绘制淡蓝色路径线连接起点和终点
6. ✅ 路径的转弯和折角与第一部分对应
7. ✅ 假设手机垂直于地面，高度1.5米（用户自行保持）

## 需要配置的项目设置

### 1. Info.plist 配置

在你的项目的 `Info.plist` 文件中添加以下权限：

```xml
<key>NSCameraUsageDescription</key>
<string>需要使用相机来提供AR导航功能</string>

<key>NSLocationWhenInUseUsageDescription</key>
<string>需要访问位置信息以提供更准确的AR导航</string>
```

### 2. 项目设置

确保在 Xcode 项目设置中：

1. **Target -> Signing & Capabilities**
   - 确保有有效的开发团队签名
   
2. **Target -> General -> Frameworks, Libraries, and Embedded Content**
   - ARKit.framework（已自动链接）
   - RealityKit.framework（已自动链接）

3. **Target -> Info -> Custom iOS Target Properties**
   - 确保 "Required device capabilities" 包含 `arkit`

### 3. 测试设备要求

⚠️ **重要**: ARKit 只能在真实的 iOS 设备上运行，不支持模拟器

- 需要支持 ARKit 的 iPhone/iPad（iPhone 6s 或更新机型）
- iOS 13.0 或更高版本
- 良好的光照条件以便AR追踪

## 代码架构

### 新增文件

1. **ARNavigationViewModel.swift**
   - 管理AR会话和导航逻辑
   - 将2D地图坐标转换为3D AR空间坐标
   - 创建3D标记物和路径线

2. **ARNavigationView.swift**
   - SwiftUI AR导航界面
   - 显示AR相机视图和覆盖UI
   - 提供导航信息和视觉反馈

### 修改的文件

1. **ContentView.swift**
   - 添加了 `showARNavigation` 状态变量
   - 添加了"Start AR Navigation"按钮
   - 只在有有效路径时显示AR按钮

## 使用方法

1. 在主界面选择起点和终点
2. 点击"Find Path"计算路径
3. 点击"Start AR Navigation"进入AR模式
4. 保持手机垂直，摄像头对准前方
5. 移动设备让ARKit初始化空间追踪
6. 蓝色正四面体标记起点和终点位置
7. 淡蓝色线条显示导航路径

## 技术实现细节

### 坐标系转换

- **2D地图坐标**: (x, y) 以像素为单位
- **3D AR坐标**: (x, y, z) 以米为单位
  - X轴: 左右方向（对应2D的X）
  - Y轴: 上下方向（固定在地面高度0）
  - Z轴: 前后方向（对应2D的Y，取反）

### 比例计算

使用 `PathfindingViewModel` 中的 `metersPerPoint` 属性，基于以下参考：
- 顶部走廊: 23.2米
- 左侧走廊: 13.6米
- 电梯区域: 8.62米（垂直）和5.46米（水平）

### AR元素

1. **蓝色正四面体（锥体）**:
   - 高度: 0.3米
   - 半径: 0.15米
   - 位置: 地面上方0.15米

2. **淡蓝色路径线**:
   - 宽度: 0.05米
   - 高度: 0.02米
   - 颜色: RGBA(0.3, 0.7, 1.0, 0.7)
   - 位置: 地面上方0.05米

3. **转角标记**:
   - 在路径转角处（角度>15度）添加小球体
   - 半径: 0.08米
   - 颜色: 浅蓝色

## 故障排除

### AR无法初始化
- 确保在真实设备上运行（不是模拟器）
- 检查相机权限是否已授予
- 确保光照条件良好

### 路径不显示
- 等待AR初始化完成（约1-2秒）
- 移动设备以帮助AR建立空间追踪
- 确保计算了有效的路径

### 比例不正确
- 检查 `metersPerPoint` 计算是否正确
- 验证参考点的坐标是否准确

## 未来改进建议

1. 添加实时定位功能，显示用户当前在路径上的位置
2. 添加语音导航提示
3. 添加距离下一个转角的实时距离显示
4. 支持路径重新计算
5. 添加AR锚点保存功能
6. 优化在不同光照条件下的性能

## 相关API文档

- [ARKit Documentation](https://developer.apple.com/documentation/arkit/)
- [RealityKit Documentation](https://developer.apple.com/documentation/realitykit/)
- [ARWorldTrackingConfiguration](https://developer.apple.com/documentation/arkit/arworldtrackingconfiguration)
