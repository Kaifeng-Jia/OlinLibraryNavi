import SwiftUI
import ARKit
import RealityKit
import Combine

class ARNavigationViewModel: NSObject, ObservableObject {
    @Published var isARReady = false
    @Published var errorMessage: String?
    
    let pathfinder: PathfindingViewModel
    var arView: ARView?
    
    // Store the path points in 3D space
    private var pathNodes: [Int: SIMD3<Float>] = [:]
    
    init(pathfinder: PathfindingViewModel) {
        self.pathfinder = pathfinder
        super.init()
    }
    
    func setupAR(arView: ARView) {
        self.arView = arView
        
        print("🔧 Setting up AR session...")
        
        // Check if AR is supported
        #if targetEnvironment(simulator)
        DispatchQueue.main.async { [weak self] in
            self?.errorMessage = "AR is not supported in Simulator. Please run on a physical device."
            print("❌ Running in simulator - AR not supported")
        }
        return
        #endif
        
        // Check if ARWorldTrackingConfiguration is supported
        guard ARWorldTrackingConfiguration.isSupported else {
            DispatchQueue.main.async { [weak self] in
                self?.errorMessage = "AR World Tracking is not supported on this device"
                print("❌ AR World Tracking not supported")
            }
            return
        }
        
        // Configure AR session
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        configuration.environmentTexturing = .automatic
        
        print("✅ AR configuration created")
        
        arView.session.run(configuration)
        arView.session.delegate = self
        
        print("✅ AR session running")
        
        // Add coaching overlay for better UX
        #if !targetEnvironment(simulator)
        let coachingOverlay = ARCoachingOverlayView()
        coachingOverlay.session = arView.session
        coachingOverlay.goal = .horizontalPlane
        coachingOverlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        arView.addSubview(coachingOverlay)
        print("✅ Coaching overlay added")
        #endif
        
        // Wait a moment for AR to initialize, then place the path
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            print("⏰ Timer fired! Attempting to place navigation path...")
            guard let self = self else {
                print("❌ Self is nil in timer callback")
                return
            }
            print("✅ Self exists, calling placeNavigationPath()")
            self.placeNavigationPath()
        }
        
        // Safety timeout - if AR isn't ready after 10 seconds, show error
        DispatchQueue.main.asyncAfter(deadline: .now() + 10.0) { [weak self] in
            guard let self = self else { return }
            if !self.isARReady {
                print("⚠️ TIMEOUT: AR not ready after 10 seconds")
                self.errorMessage = "AR初始化超时。请重试。"
                self.isARReady = true // Stop the spinner
            }
        }
    }
    
    func placeNavigationPath() {
        print("📍 placeNavigationPath() called")
        
        guard let arView = arView else {
            print("❌ ARView is nil")
            DispatchQueue.main.async { [weak self] in
                self?.errorMessage = "AR View not initialized"
                self?.isARReady = true // Set to true even on error to stop spinner
            }
            return
        }
        
        print("✅ ARView exists, starting to place navigation path...")
        print("🗺️ Path has \(pathfinder.path.count) points")
        print("🗺️ Path: \(pathfinder.path)")
        
        // Convert 2D map coordinates to 3D AR coordinates
        let positions3D = convert2DPathTo3D()
        
        print("📐 convert2DPathTo3D returned \(positions3D.count) positions")
        
        guard !positions3D.isEmpty else {
            print("❌ No 3D positions generated")
            print("❌ Path count was: \(pathfinder.path.count)")
            print("❌ Locations available: \(pathfinder.locations.count)")
            DispatchQueue.main.async { [weak self] in
                self?.errorMessage = "Failed to convert path to 3D"
                self?.isARReady = true // Set to true to stop spinner
            }
            return
        }
        
        print("✅ Generated \(positions3D.count) 3D positions")
        print("📊 First position: \(positions3D.first!)")
        print("📊 Last position: \(positions3D.last!)")
        
        // Create anchor at origin (user's starting position)
        let anchor = AnchorEntity(world: [0, 0, 0])
        arView.scene.addAnchor(anchor)
        
        print("✅ Added anchor to scene")
        
        // Create start and end markers (blue tetrahedrons)
        if let startPos = positions3D.first {
            let startMarker = createTetrahedron(color: .blue, position: startPos)
            anchor.addChild(startMarker)
            print("✅ Added start marker at \(startPos)")
        }
        
        if let endPos = positions3D.last {
            let endMarker = createTetrahedron(color: .blue, position: endPos)
            anchor.addChild(endMarker)
            print("✅ Added end marker at \(endPos)")
        }
        
        // Create path line connecting all points
        if positions3D.count > 1 {
            createPathLine(positions: positions3D, anchor: anchor)
            print("✅ Created path line with \(positions3D.count) points")
        }
        
        DispatchQueue.main.async { [weak self] in
            self?.isARReady = true
            print("✅ AR is ready!")
        }
    }
    
    // Convert 2D map coordinates to 3D AR space
    private func convert2DPathTo3D() -> [SIMD3<Float>] {
        print("🔄 Starting convert2DPathTo3D...")
        var result: [SIMD3<Float>] = []
        
        print("📝 Path count: \(pathfinder.path.count)")
        guard pathfinder.path.count > 1 else {
            print("❌ Path count is <= 1")
            return result
        }
        
        // Get the scale factor from the pathfinder
        let metersPerPoint = Float(pathfinder.metersPerPoint)
        print("📏 Meters per point: \(metersPerPoint)")
        
        // Get start position as reference point (0, 0 in AR space)
        let firstNodeId = pathfinder.path[0]
        print("🎯 First node ID: \(firstNodeId)")
        
        guard let startPoint = pathfinder.locations[firstNodeId] else {
            print("❌ Could not find location for first node \(firstNodeId)")
            print("❌ Available locations: \(pathfinder.locations.keys.sorted())")
            return result
        }
        
        print("✅ Start point found: \(startPoint)")
        
        // Convert each point in the path
        for (index, nodeId) in pathfinder.path.enumerated() {
            guard let point2D = pathfinder.locations[nodeId] else {
                print("⚠️ Could not find location for node \(nodeId) at index \(index)")
                continue
            }
            
            // Calculate offset from start point
            let dx = Float(point2D.x - startPoint.x) * metersPerPoint
            let dz = Float(point2D.y - startPoint.y) * metersPerPoint
            
            let position3D = SIMD3<Float>(dx, 0.0, -dz)
            result.append(position3D)
            pathNodes[nodeId] = position3D
            
            if index < 3 || index == pathfinder.path.count - 1 {
                print("  Node \(nodeId): 2D(\(point2D.x), \(point2D.y)) → 3D(\(dx), 0, \(-dz))")
            }
        }
        
        print("✅ Converted \(result.count) positions")
        return result
    }
    
    // Create a tetrahedron (pyramid with triangular base)
    private func createTetrahedron(color: UIColor, position: SIMD3<Float>) -> ModelEntity {
        print("🔺 Creating tetrahedron at \(position)")
        
        // Use a cone as a simpler alternative to tetrahedron
        // This is more stable and less likely to crash
        let mesh = MeshResource.generateCone(height: 0.3, radius: 0.15)
        
        var material = SimpleMaterial()
        material.color = .init(tint: color)
        material.roughness = .float(0.2)
        material.metallic = .float(0.1)
        
        let model = ModelEntity(mesh: mesh, materials: [material])
        
        // Position the marker slightly above ground
        model.position = position + SIMD3<Float>(0, 0.15, 0)
        
        print("✅ Tetrahedron created successfully")
        return model
    }
    
    // Create the path line connecting waypoints
    private func createPathLine(positions: [SIMD3<Float>], anchor: AnchorEntity) {
        guard positions.count > 1 else { return }
        
        print("🛤️ Creating path line with \(positions.count) positions")
        
        // Create path material
        var pathMaterial = SimpleMaterial()
        pathMaterial.color = .init(tint: UIColor(red: 0.3, green: 0.7, blue: 1.0, alpha: 0.7))
        pathMaterial.roughness = .float(0.5)
        pathMaterial.metallic = .float(0.0)
        
        // Create line segments between each pair of points
        for i in 0..<(positions.count - 1) {
            let start = positions[i]
            let end = positions[i + 1]
            
            let midpoint = (start + end) / 2
            let direction = end - start
            let distance = length(direction)
            
            // Create a box mesh for the line segment
            let mesh = MeshResource.generateBox(width: 0.05, height: 0.02, depth: distance)
            let lineSegment = ModelEntity(mesh: mesh, materials: [pathMaterial])
            
            // Position and rotate
            lineSegment.position = midpoint + SIMD3<Float>(0, 0.05, 0)
            let angle = atan2(direction.x, direction.z)
            lineSegment.orientation = simd_quatf(angle: -angle, axis: [0, 1, 0])
            
            anchor.addChild(lineSegment)
        }
        
        print("✅ Path line created successfully")
        
        // Add turning indicators at corners
        addCornerMarkers(positions: positions, anchor: anchor)
    }
    
    // Add small markers at path corners
    private func addCornerMarkers(positions: [SIMD3<Float>], anchor: AnchorEntity) {
        // Skip start and end positions (they already have tetrahedrons)
        guard positions.count > 2 else { return }
        
        print("🔄 Adding corner markers...")
        
        for i in 1..<(positions.count - 1) {
            let pos = positions[i]
            let prev = positions[i - 1]
            let next = positions[i + 1]
            
            // Check if this is a significant corner
            let dir1 = normalize(pos - prev)
            let dir2 = normalize(next - pos)
            
            let dotProduct = dot(dir1, dir2)
            let angle = acos(max(-1.0, min(1.0, dotProduct)))
            
            // Only add marker if angle is significant (more than 15 degrees)
            if angle > 0.26 { // ~15 degrees in radians
                let mesh = MeshResource.generateSphere(radius: 0.08)
                var material = SimpleMaterial()
                material.color = .init(tint: UIColor(red: 0.5, green: 0.8, blue: 1.0, alpha: 0.8))
                
                let marker = ModelEntity(mesh: mesh, materials: [material])
                marker.position = pos + SIMD3<Float>(0, 0.05, 0)
                
                anchor.addChild(marker)
            }
        }
        
        print("✅ Corner markers added")
    }
}

// MARK: - ARSessionDelegate
extension ARNavigationViewModel: ARSessionDelegate {
    func session(_ session: ARSession, didFailWithError error: Error) {
        DispatchQueue.main.async { [weak self] in
            self?.errorMessage = "AR Session failed: \(error.localizedDescription)"
        }
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        DispatchQueue.main.async { [weak self] in
            self?.errorMessage = "AR Session was interrupted"
        }
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        DispatchQueue.main.async { [weak self] in
            self?.errorMessage = nil
        }
    }
}
