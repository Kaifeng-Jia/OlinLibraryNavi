import SwiftUI

@main
struct OlinLibraryNavigatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
