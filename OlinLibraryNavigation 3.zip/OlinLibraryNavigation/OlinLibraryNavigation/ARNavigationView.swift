import SwiftUI
import ARKit
import RealityKit

struct ARNavigationView: View {
    @ObservedObject var pathfinder: PathfindingViewModel
    @StateObject private var arViewModel: ARNavigationViewModel
    @Environment(\.presentationMode) var presentationMode
    
    init(pathfinder: PathfindingViewModel) {
        self.pathfinder = pathfinder
        _arViewModel = StateObject(wrappedValue: ARNavigationViewModel(pathfinder: pathfinder))
        print("🎬 ARNavigationView initialized")
    }
    
    var body: some View {
        ZStack {
            // AR View
            ARViewContainer(viewModel: arViewModel)
                .edgesIgnoringSafeArea(.all)
                .onAppear {
                    print("👁️ ARNavigationView appeared")
                }
                .onDisappear {
                    print("👋 ARNavigationView disappeared")
                }
            
            // Overlay UI
            VStack {
                // Top info bar
                VStack(spacing: 8) {
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 28))
                                .foregroundColor(.white)
                                .shadow(color: .black.opacity(0.3), radius: 3, x: 0, y: 2)
                        }
                        
                        Spacer()
                        
                        VStack(alignment: .trailing, spacing: 4) {
                            Text("AR Navigation")
                                .font(.headline)
                                .foregroundColor(.white)
                            
                            if let distance = pathfinder.pathDistance {
                                Text("\(String(format: "%.1f", distance))m total")
                                    .font(.caption)
                                    .foregroundColor(.white.opacity(0.9))
                            }
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 50)
                    
                    // Navigation info
                    HStack(spacing: 12) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("From:")
                                .font(.caption)
                                .foregroundColor(.white.opacity(0.8))
                            Text(pathfinder.locationNames[pathfinder.startPoint] ?? "Unknown")
                                .font(.footnote)
                                .foregroundColor(.white)
                        }
                        
                        Image(systemName: "arrow.right")
                            .foregroundColor(.white)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("To:")
                                .font(.caption)
                                .foregroundColor(.white.opacity(0.8))
                            Text(pathfinder.locationNames[pathfinder.endPoint] ?? "Unknown")
                                .font(.footnote)
                                .foregroundColor(.white)
                        }
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color.black.opacity(0.6))
                            .blur(radius: 10)
                    )
                    .padding(.horizontal)
                }
                
                Spacer()
                
                // Bottom instructions
                VStack(spacing: 12) {
                    if !arViewModel.isARReady {
                        HStack {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            Text("Initializing AR...")
                                .font(.subheadline)
                                .foregroundColor(.white)
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.black.opacity(0.6))
                        )
                    } else {
                        VStack(spacing: 8) {
                            HStack(spacing: 8) {
                                Circle()
                                    .fill(Color.blue)
                                    .frame(width: 12, height: 12)
                                Text("Blue markers: Start & End points")
                                    .font(.caption)
                                    .foregroundColor(.white)
                            }
                            
                            HStack(spacing: 8) {
                                Rectangle()
                                    .fill(Color(red: 0.3, green: 0.7, blue: 1.0))
                                    .frame(width: 20, height: 3)
                                Text("Light blue line: Navigation path")
                                    .font(.caption)
                                    .foregroundColor(.white)
                            }
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.black.opacity(0.6))
                        )
                    }
                    
                    if let error = arViewModel.errorMessage {
                        Text(error)
                            .font(.caption)
                            .foregroundColor(.red)
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color.white.opacity(0.9))
                            )
                    }
                    
                    // Camera height indicator
                    HStack {
                        Image(systemName: "camera.fill")
                        Text("Hold phone vertical at ~1.5m height")
                            .font(.caption2)
                    }
                    .foregroundColor(.white.opacity(0.8))
                    .padding(.horizontal)
                    .padding(.bottom, 40)
                }
            }
        }
        .navigationBarHidden(true)
    }
}

// MARK: - ARViewContainer
struct ARViewContainer: UIViewRepresentable {
    let viewModel: ARNavigationViewModel
    
    func makeUIView(context: Context) -> ARView {
        print("🏗️ Creating ARView...")
        
        let arView = ARView(frame: .zero)
        print("✅ ARView created")
        
        // Configure rendering
        arView.environment.lighting.intensityExponent = 1.5
        arView.renderOptions = [.disableDepthOfField, .disableMotionBlur]
        print("✅ ARView configured")
        
        // Setup AR session
        print("🚀 Calling setupAR...")
        viewModel.setupAR(arView: arView)
        
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {
        // Update if needed
    }
    
    static func dismantleUIView(_ uiView: ARView, coordinator: ()) {
        print("🛑 Dismantling ARView, pausing session")
        uiView.session.pause()
    }
}

struct ARNavigationView_Previews: PreviewProvider {
    static var previews: some View {
        ARNavigationView(pathfinder: PathfindingViewModel())
    }
}
