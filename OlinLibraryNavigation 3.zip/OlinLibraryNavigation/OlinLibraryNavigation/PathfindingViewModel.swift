import SwiftUI
import Combine

class PathfindingViewModel: ObservableObject {
    @Published var startPoint: Int = 1
    @Published var endPoint: Int = 35
    @Published var path: [Int] = []
    @Published var pathDistance: Double? = nil
    @Published var errorMessage: String? = nil
    
    // All 64 locations based on official Olin Library 3rd floor map
    let locations: [Int: CGPoint] = [
        // Top corridor - Graduate & Faculty Reading Rooms (1-12)
        1: CGPoint(x: 110, y: 50),
        2: CGPoint(x: 145, y: 50),
        3: CGPoint(x: 180, y: 50),
        4: CGPoint(x: 215, y: 50),
        5: CGPoint(x: 250, y: 50),
        6: CGPoint(x: 285, y: 50),
        7: CGPoint(x: 320, y: 50),
        8: CGPoint(x: 355, y: 50),
        9: CGPoint(x: 390, y: 50),
        10: CGPoint(x: 425, y: 50),
        11: CGPoint(x: 460, y: 50),
        12: CGPoint(x: 495, y: 50),
        
        // Left corridor - Graduate & Faculty Reading Rooms (13-31)
        13: CGPoint(x: 68, y: 82),
        14: CGPoint(x: 68, y: 127),
        15: CGPoint(x: 68, y: 178),
        16: CGPoint(x: 68, y: 235),
        17: CGPoint(x: 68, y: 290),
        18: CGPoint(x: 68, y: 345),
        19: CGPoint(x: 68, y: 408),
        20: CGPoint(x: 68, y: 467),
        21: CGPoint(x: 68, y: 521),
        22: CGPoint(x: 68, y: 581),
        23: CGPoint(x: 68, y: 636),
        24: CGPoint(x: 68, y: 691),
        25: CGPoint(x: 68, y: 748),
        26: CGPoint(x: 68, y: 807),
        27: CGPoint(x: 68, y: 863),
        28: CGPoint(x: 68, y: 923),
        29: CGPoint(x: 68, y: 983),
        30: CGPoint(x: 68, y: 1030),
        31: CGPoint(x: 68, y: 1085),
        
        // Bottom area
        32: CGPoint(x: 133, y: 1180),
        33: CGPoint(x: 287, y: 1207),
        34: CGPoint(x: 373, y: 1207),
        35: CGPoint(x: 485, y: 1180),
        
        // Right side corridor (not in book stacks)
        36: CGPoint(x: 530, y: 1033),
        37: CGPoint(x: 530, y: 897),
        38: CGPoint(x: 530, y: 743),
        39: CGPoint(x: 530, y: 567),
        40: CGPoint(x: 530, y: 385),
        41: CGPoint(x: 530, y: 220),
        42: CGPoint(x: 530, y: 157),
        
        // Central stairwell
        43: CGPoint(x: 305, y: 242),
        44: CGPoint(x: 260, y: 190),
        
        // Connecting points (in white walkways only)
        45: CGPoint(x: 110, y: 82),   // Top-left corner connector
        46: CGPoint(x: 260, y: 82),   // Top center connector
        47: CGPoint(x: 495, y: 82),   // Top-right corner connector
        
        48: CGPoint(x: 68, y: 280),   // Left mid corridor
        49: CGPoint(x: 68, y: 620),   // Left lower-mid corridor  
        50: CGPoint(x: 68, y: 1000),  // Left bottom corridor
        
        51: CGPoint(x: 530, y: 280),  // Right mid corridor
        52: CGPoint(x: 530, y: 620),  // Right lower-mid corridor
        53: CGPoint(x: 530, y: 1000), // Right bottom corridor
        
        // Bottom area connectors
        54: CGPoint(x: 260, y: 1140), // Bottom center-left
        55: CGPoint(x: 350, y: 1140), // Bottom center
        56: CGPoint(x: 440, y: 1140), // Bottom center-right
        
        // Facilities
        57: CGPoint(x: 230, y: 1057), // Stairwell bottom
        58: CGPoint(x: 290, y: 1067), // Emergency phone
        59: CGPoint(x: 350, y: 1055), // Elevators
        60: CGPoint(x: 400, y: 1050), // Restroom area
        61: CGPoint(x: 285, y: 925),  // Catalog terminal
        62: CGPoint(x: 315, y: 980),  // Freight elevator
        63: CGPoint(x: 383, y: 1003), // Men's restroom
        64: CGPoint(x: 383, y: 1095), // Women's restroom
    ]
    
    let locationNames: [Int: String] = [
        1: "Graduate Reading Room", 2: "Graduate Reading Room", 3: "Graduate Reading Room",
        4: "Graduate Reading Room", 5: "Graduate Reading Room", 6: "Graduate Reading Room",
        7: "Graduate Reading Room", 8: "Graduate Reading Room", 9: "Graduate Reading Room",
        10: "Graduate Reading Room", 11: "Graduate Reading Room", 12: "Graduate Reading Room",
        13: "Graduate Reading Room", 14: "Graduate Reading Room", 15: "Graduate Reading Room",
        16: "Graduate Reading Room", 17: "Graduate Reading Room", 18: "Graduate Reading Room",
        19: "Graduate Reading Room", 20: "Graduate Reading Room", 21: "Graduate Reading Room",
        22: "Graduate Reading Room", 23: "Graduate Reading Room", 24: "Graduate Reading Room",
        25: "Graduate Reading Room", 26: "Graduate Reading Room", 27: "Graduate Reading Room",
        28: "Graduate Reading Room", 29: "Graduate Reading Room", 30: "Graduate Reading Room",
        31: "Graduate Reading Room",
        32: "Exit Area", 33: "Conference Room 303", 34: "Group Study Room 302", 35: "Reading Room 301",
        36: "Right Corridor", 37: "Right Corridor", 38: "Right Corridor", 39: "Right Corridor",
        40: "Right Corridor", 41: "Right Corridor", 42: "Right Corridor",
        43: "Emergency Phone", 44: "Stairwell",
        45: "Corridor", 46: "Corridor", 47: "Corridor",
        48: "Corridor", 49: "Corridor", 50: "Corridor",
        51: "Corridor", 52: "Corridor", 53: "Corridor",
        54: "Corridor", 55: "Corridor", 56: "Corridor",
        57: "Stairwell", 58: "Emergency Phone", 59: "Elevators", 60: "Restroom Area",
        61: "Catalog Terminal", 62: "Freight Elevator", 63: "Men's Restroom", 64: "Women's Restroom"
    ]
    
    // Compute meters-per-point (pixel) scale from two known references
    // Reference A: Top corridor span from 1 to 12 is 23.2 meters
    // Reference B: Left corridor span from 13 to 17 is 13.6 meters
    var metersPerPoint: Double {
        // Safely get points for references
        guard let p1 = locations[1], let p12 = locations[12],
              let p13 = locations[13], let p17 = locations[17] else {
            // Fallback to a reasonable default if data missing
            return 0.25
        }
        // Pixel distances for the two original references
        let topDx = p1.x - p12.x
        let topDy = p1.y - p12.y
        let topPixels = sqrt(topDx * topDx + topDy * topDy)
        let leftDx = p13.x - p17.x
        let leftDy = p13.y - p17.y
        let leftPixels = sqrt(leftDx * leftDx + leftDy * leftDy)

        // Known real distances (meters)
        let topMeters = 23.2
        let leftMeters = 13.6

        // Compute meters per pixel for each original reference
        let topMPP = Double(topMeters) / Double(topPixels)
        let leftMPP = Double(leftMeters) / Double(leftPixels)

        // Optional third reference: Elevator/Restroom area (nodes 63 and 64)
        // Use vertical span between Men's (63) and Women's (64) restrooms as 8.62 meters
        var weightedSum: Double = topMPP * Double(topPixels) + leftMPP * Double(leftPixels)
        var totalPixels: Double = Double(topPixels + leftPixels)
        if let p63 = locations[63], let p64 = locations[64] {
            let dx = p63.x - p64.x
            let dy = p63.y - p64.y
            let pix = sqrt(dx * dx + dy * dy)
            if pix > 0 {
                let elevatorMeters = 8.62
                let mpp = Double(elevatorMeters) / Double(pix)
                weightedSum += mpp * Double(pix)
                totalPixels += Double(pix)
            }
        }

        // Optional fourth reference: Horizontal span between 62 and 64 is 5.46 meters
        if let p62 = locations[62], let p64 = locations[64] {
            // Use pure horizontal pixel span to respect the measurement direction
            let horizontalPixels = abs(Double(p62.x - p64.x))
            if horizontalPixels > 0 {
                let horizontalMeters = 5.46
                let mpp = horizontalMeters / horizontalPixels
                weightedSum += mpp * horizontalPixels
                totalPixels += horizontalPixels
            }
        }

        if totalPixels > 0 {
            return weightedSum / totalPixels
        } else {
            return 0.25
        }
    }
    
    // CORRECTED: Only connections through WHITE walkable corridors
    let connections: [Int: [Int]] = [
        // Top corridor - only horizontal connections
        1: [2, 45],
        2: [1, 3],
        3: [2, 4],
        4: [3, 5],
        5: [4, 6],
        6: [5, 7, 46],
        7: [6, 8],
        8: [7, 9],
        9: [8, 10],
        10: [9, 11],
        11: [10, 12],
        12: [11, 47],
        
        // Top connectors
        45: [1, 13],          // Top-left corner
        46: [6, 44],          // Top-center to stairwell
        47: [12, 42],         // Top-right corner
        
        // Left corridor - only vertical connections
        13: [45, 14],
        14: [13, 15],
        15: [14, 16],
        16: [15, 17],
        17: [16, 18, 48],
        18: [17, 19],
        19: [18, 20],
        20: [19, 21],
        21: [20, 22],
        22: [21, 23],
        23: [22, 24, 49],
        24: [23, 25],
        25: [24, 26],
        26: [25, 27],
        27: [26, 28],
        28: [27, 29],
        29: [28, 30, 50],
        30: [29, 31],
        31: [30, 54],
        
        // Left corridor mid-points
        48: [17],            // Just a marker
        49: [23],            // Just a marker
        50: [29],            // Just a marker
        
        // Right corridor - only vertical connections
        42: [47, 41],
        41: [42, 40],
        40: [41, 39, 51],
        39: [40, 38],
        38: [39, 37, 52],
        37: [38, 36],
        36: [37, 53],
        
        // Right corridor mid-points
        51: [40],            // Just a marker
        52: [38],            // Just a marker
        53: [36, 56],        // Connect to bottom
        
        // Central stairwell
        44: [46, 43],
        43: [44],
        
        // Bottom area
        54: [31, 55, 57],
        55: [54, 56, 59],
        56: [53, 55, 35],
        
        57: [54, 58],        // Stairwell
        58: [57, 59],        // Emergency phone
        59: [55, 58, 60],    // Elevators
        60: [59, 63, 64],    // Restroom area
        
        63: [60],            // Men's restroom
        64: [60],            // Women's restroom
        
        33: [54, 34],        // Conference room
        34: [33, 55],        // Study room
        35: [56],            // Reading room
        
        32: [54],            // Exit
        61: [50],            // Catalog terminal
        62: [50],            // Freight elevator
    ]
    
    func calculatePath() {
        errorMessage = nil
        pathDistance = nil
        path = []
        
        guard locations[startPoint] != nil else {
            errorMessage = "Start location #\(startPoint) not found"
            return
        }
        
        guard locations[endPoint] != nil else {
            errorMessage = "End location #\(endPoint) not found"
            return
        }
        
        if startPoint == endPoint {
            errorMessage = "Start and end are the same"
            return
        }
        
        if let foundPath = findPath(from: startPoint, to: endPoint) {
            path = foundPath
            pathDistance = getDistance(foundPath)
        } else {
            errorMessage = "No path found between these locations"
        }
    }
    
    func findPath(from start: Int, to goal: Int) -> [Int]? {
        var openSet = Set<Int>([start])
        var cameFrom = [Int: Int]()
        var gScore = [Int: Double]()
        var fScore = [Int: Double]()
        
        for loc in locations.keys {
            gScore[loc] = Double.infinity
            fScore[loc] = Double.infinity
        }
        
        gScore[start] = 0
        fScore[start] = heuristic(from: start, to: goal)
        
        while !openSet.isEmpty {
            guard let current = openSet.min(by: { fScore[$0]! < fScore[$1]! }) else { break }
            
            if current == goal {
                return buildPath(cameFrom: cameFrom, current: current)
            }
            
            openSet.remove(current)
            
            guard let neighbors = connections[current] else { continue }
            
            for neighbor in neighbors {
                let tentative = gScore[current]! + dist(from: current, to: neighbor)
                
                if tentative < gScore[neighbor]! {
                    cameFrom[neighbor] = current
                    gScore[neighbor] = tentative
                    fScore[neighbor] = tentative + heuristic(from: neighbor, to: goal)
                    openSet.insert(neighbor)
                }
            }
        }
        
        return nil
    }
    
    func buildPath(cameFrom: [Int: Int], current: Int) -> [Int] {
        var result = [current]
        var curr = current
        
        while let prev = cameFrom[curr] {
            result.insert(prev, at: 0)
            curr = prev
        }
        
        return result
    }
    
    func heuristic(from: Int, to: Int) -> Double {
        guard let p1 = locations[from], let p2 = locations[to] else {
            return Double.infinity
        }
        let dx = p1.x - p2.x
        let dy = p1.y - p2.y
        return sqrt(dx * dx + dy * dy)
    }
    
    func dist(from: Int, to: Int) -> Double {
        return heuristic(from: from, to: to)
    }
    
    func getDistance(_ path: [Int]) -> Double {
        var total: Double = 0
        for i in 0..<(path.count - 1) {
            total += dist(from: path[i], to: path[i + 1])
        }
        // Convert from points (pixels) to meters using calibrated scale
        return total * metersPerPoint
    }
}

