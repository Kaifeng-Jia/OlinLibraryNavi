import Foundation
import RealityKit
import ARKit

/// Helper class to create custom 3D geometries for AR navigation
class ARGeometryHelper {
    
    /// Creates a regular tetrahedron (正四面体) mesh
    /// - Parameters:
    ///   - size: The edge length of the tetrahedron in meters
    /// - Returns: A MeshResource representing a tetrahedron
    static func createTetrahedronMesh(size: Float = 0.3) -> MeshResource {
        // A regular tetrahedron has 4 vertices and 4 triangular faces
        // Calculate vertices for a tetrahedron centered at origin
        let height = size * sqrt(2.0/3.0)
        let radius = size * sqrt(3.0) / 3.0
        
        // Define the 4 vertices of the tetrahedron
        let vertices: [SIMD3<Float>] = [
            // Base triangle (on XZ plane)
            SIMD3<Float>(0, -height/3, radius),                    // Front
            SIMD3<Float>(-size/2, -height/3, -radius/2),          // Back left
            SIMD3<Float>(size/2, -height/3, -radius/2),           // Back right
            // Apex
            SIMD3<Float>(0, height * 2/3, 0)                       // Top
        ]
        
        // Define the 4 triangular faces (counterclockwise winding)
        let indices: [UInt32] = [
            // Base
            0, 2, 1,
            // Side faces
            0, 1, 3,
            1, 2, 3,
            2, 0, 3
        ]
        
        // Calculate normals for each vertex
        var normals: [SIMD3<Float>] = []
        for vertex in vertices {
            let normal = normalize(vertex)
            normals.append(normal)
        }
        
        // Create mesh descriptor
        var descriptor = MeshDescriptor(name: "tetrahedron")
        descriptor.positions = MeshBuffer(vertices)
        descriptor.normals = MeshBuffer(normals)
        descriptor.primitives = .triangles(indices)
        
        return try! MeshResource.generate(from: [descriptor])
    }
    
    /// Creates a line segment between two points
    /// - Parameters:
    ///   - start: Start position in 3D space
    ///   - end: End position in 3D space
    ///   - thickness: Thickness of the line
    /// - Returns: Configuration for a line segment entity
    static func createLineSegment(from start: SIMD3<Float>, to end: SIMD3<Float>, thickness: Float = 0.05) -> (position: SIMD3<Float>, rotation: simd_quatf, scale: SIMD3<Float>) {
        // Calculate midpoint
        let midpoint = (start + end) / 2
        
        // Calculate direction and distance
        let direction = end - start
        let distance = length(direction)
        
        // Calculate rotation to align with direction
        let defaultDirection = SIMD3<Float>(0, 0, 1) // Default forward direction
        let normalizedDirection = normalize(direction)
        
        // Calculate rotation quaternion
        let rotationAxis = cross(defaultDirection, normalizedDirection)
        let rotationAngle = acos(dot(defaultDirection, normalizedDirection))
        
        var rotation: simd_quatf
        if length(rotationAxis) > 0.001 {
            rotation = simd_quatf(angle: rotationAngle, axis: normalize(rotationAxis))
        } else {
            // Directions are parallel
            rotation = simd_quatf(angle: 0, axis: SIMD3<Float>(0, 1, 0))
        }
        
        // Scale to match distance
        let scale = SIMD3<Float>(thickness, thickness, distance)
        
        return (position: midpoint, rotation: rotation, scale: scale)
    }
    
    /// Creates a corner indicator sphere
    /// - Parameters:
    ///   - position: Position in 3D space
    ///   - radius: Radius of the sphere
    /// - Returns: A ModelEntity for the corner marker
    static func createCornerMarker(at position: SIMD3<Float>, radius: Float = 0.08) -> ModelEntity {
        let mesh = MeshResource.generateSphere(radius: radius)
        var material = SimpleMaterial()
        material.color = .init(tint: UIColor(red: 0.5, green: 0.8, blue: 1.0, alpha: 0.8))
        material.roughness = .float(0.3)
        material.metallic = .float(0.1)
        
        let entity = ModelEntity(mesh: mesh, materials: [material])
        entity.position = position
        
        return entity
    }
    
    /// Calculates if a point is a significant corner based on angle
    /// - Parameters:
    ///   - previous: Previous point in path
    ///   - current: Current point (potential corner)
    ///   - next: Next point in path
    /// - Returns: True if the angle is significant enough to mark as a corner
    static func isSignificantCorner(previous: SIMD3<Float>, current: SIMD3<Float>, next: SIMD3<Float>, minimumAngle: Float = 0.26) -> Bool {
        let dir1 = normalize(current - previous)
        let dir2 = normalize(next - current)
        
        let dotProduct = dot(dir1, dir2)
        let angle = acos(max(-1.0, min(1.0, dotProduct)))
        
        return angle > minimumAngle // ~15 degrees
    }
    
    /// Creates an animated pulse effect for markers
    /// - Parameter entity: The entity to animate
    static func addPulseAnimation(to entity: ModelEntity) {
        // Create a simple scale animation
        let originalScale = entity.scale
        let largerScale = originalScale * 1.2
        
        // Note: For a complete implementation, you would use RealityKit's animation system
        // This is a placeholder for the animation setup
        // In practice, you might use Transform components and AnimationResource
    }
    
    /// Creates a gradient material for the path line
    /// - Returns: A material with light blue color and transparency
    static func createPathMaterial() -> SimpleMaterial {
        var material = SimpleMaterial()
        material.color = .init(tint: UIColor(red: 0.3, green: 0.7, blue: 1.0, alpha: 0.7))
        material.roughness = .float(0.5)
        material.metallic = .float(0.0)
        return material
    }
    
    /// Creates a material for the tetrahedron markers
    /// - Parameter color: The base color
    /// - Returns: A material suitable for markers
    static func createMarkerMaterial(color: UIColor) -> SimpleMaterial {
        var material = SimpleMaterial()
        material.color = .init(tint: color)
        material.roughness = .float(0.2)
        material.metallic = .float(0.1)
        return material
    }
}
