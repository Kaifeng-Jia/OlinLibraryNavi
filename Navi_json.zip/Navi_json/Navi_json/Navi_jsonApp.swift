//
//  Navi_jsonApp.swift
//  Navi_json
//
//  Created by Kaifeng Jia on 4/12/26.
//

import SwiftUI

@main
struct Navi_jsonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
