//
//  MapViewController.swift
//  Navi_json
//
//  Created by Kaifeng Jia on 4/12/26.
//

import UIKit

class MapViewController: UIViewController {
    private var imageView: UIImageView!
    private var overlayView: FloorplanOverlayView!
    private var navigationButton: UIButton!
    
    private var graph: NavGraph!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Indoor Navigation"
        view.backgroundColor = .white
        
        loadAssets()
    }
    
    private func loadAssets() {
        do {
            graph = try GraphLoader.load()
        } catch GraphLoadError.fileNotFound {
            showError("Navigation data file not found\n\nPlease add 'nav_graph_with_candidates.json' to the project")
            return
        } catch GraphLoadError.decodeFailed(let message) {
            showError("Failed to parse navigation data:\n\n\(message)")
            return
        } catch {
            showError("Failed to load navigation data:\n\n\(error.localizedDescription)")
            return
        }
        
        guard let image = UIImage(named: "02_floorplan_crop") else {
            showError("Floorplan image not found")
            return
        }
        
        setupImageView(with: image)
        setupOverlayView(with: graph)
        setupNavigationButton()
    }
    
    private func showError(_ message: String) {
        let label = UILabel()
        label.text = message
        label.textAlignment = .center
        label.textColor = .systemRed
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            label.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40)
        ])
    }
    
    private func setupImageView(with image: UIImage) {
        imageView = UIImageView(image: image)
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            imageView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    private func setupOverlayView(with graph: NavGraph) {
        overlayView = FloorplanOverlayView()
        overlayView.configure(graph: graph)
        overlayView.onRouteChanged = { [weak self] in
            self?.updateNavigationButtonState()
        }
        overlayView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(overlayView)
        
        NSLayoutConstraint.activate([
            overlayView.topAnchor.constraint(equalTo: imageView.topAnchor),
            overlayView.leadingAnchor.constraint(equalTo: imageView.leadingAnchor),
            overlayView.trailingAnchor.constraint(equalTo: imageView.trailingAnchor),
            overlayView.bottomAnchor.constraint(equalTo: imageView.bottomAnchor)
        ])
    }
    
    private func setupNavigationButton() {
        navigationButton = UIButton(type: .system)
        navigationButton.setTitle("Start AR Navigation", for: .normal)
        navigationButton.setTitle("Select start and end nodes", for: .disabled)
        navigationButton.titleLabel?.font = .boldSystemFont(ofSize: 18)
        navigationButton.backgroundColor = .systemBlue
        navigationButton.setTitleColor(.white, for: .normal)
        navigationButton.setTitleColor(.lightGray, for: .disabled)
        navigationButton.layer.cornerRadius = 12
        navigationButton.translatesAutoresizingMaskIntoConstraints = false
        navigationButton.addTarget(self, action: #selector(startARNavigation), for: .touchUpInside)
        navigationButton.isEnabled = false
        view.addSubview(navigationButton)
        
        NSLayoutConstraint.activate([
            navigationButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            navigationButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            navigationButton.widthAnchor.constraint(equalToConstant: 250),
            navigationButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    private func updateNavigationButtonState() {
        let isValid = overlayView.startNode != nil &&
                      overlayView.endNode != nil &&
                      !overlayView.routePath.isEmpty
        navigationButton.isEnabled = isValid
        navigationButton.backgroundColor = isValid ? .systemBlue : .systemGray
    }
    
    @objc private func startARNavigation() {
        guard let start = overlayView.startNode,
              let end = overlayView.endNode,
              !overlayView.routePath.isEmpty else { return }
        
        let arVC = ARNavigationViewController(
            graph: graph,
            startNodeID: start,
            endNodeID: end,
            routePath: overlayView.routePath
        )
        navigationController?.pushViewController(arVC, animated: true)
    }
}
