//
//  PathPlanner.swift
//  Navi_json
//
//  Created by Kaifeng Jia on 4/12/26.
//

import Foundation

struct PathPlanner {
    let graph: NavGraph
    let adjacency: AdjacencyList
    
    func findPath(from startID: String, to endID: String) -> [String]? {
        var dist: [String: Double] = [:]
        var prev: [String: String] = [:]
        var visited: Set<String> = []
        var queue: Set<String> = []
        
        let nodeMap = Dictionary(uniqueKeysWithValues: graph.nodes.map { ($0.id, $0) })
        
        for node in graph.nodes {
            dist[node.id] = .infinity
            queue.insert(node.id)
        }
        dist[startID] = 0
        
        while !queue.isEmpty {
            guard let u = queue.min(by: { dist[$0]! < dist[$1]! }) else { break }
            queue.remove(u)
            visited.insert(u)
            
            if u == endID { break }
            
            for v in adjacency.neighbors[u] ?? [] where !visited.contains(v) {
                let alt = dist[u]! + distance(nodeMap[u]!, nodeMap[v]!)
                if alt < dist[v]! {
                    dist[v] = alt
                    prev[v] = u
                }
            }
        }
        
        guard dist[endID] != .infinity else { return nil }
        
        var path: [String] = []
        var current: String? = endID
        while let node = current {
            path.insert(node, at: 0)
            current = prev[node]
        }
        return path
    }
    
    private func distance(_ a: Node, _ b: Node) -> Double {
        let dx = a.meterX - b.meterX
        let dy = a.meterY - b.meterY
        return sqrt(dx*dx + dy*dy)
    }
}
