//
//  ContentView.swift
//  Navi_json
//
//  Created by Kaifeng Jia on 4/12/26.
//

import SwiftUI
import UIKit

struct ContentView: View {
    var body: some View {
        MapViewControllerRepresentable()
            .ignoresSafeArea()
    }
}

struct MapViewControllerRepresentable: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UINavigationController {
        let mapVC = MapViewController()
        let navController = UINavigationController(rootViewController: mapVC)
        return navController
    }
    
    func updateUIViewController(_ uiViewController: UINavigationController, context: Context) {
        // No update needed
    }
}

#Preview {
    ContentView()
}
