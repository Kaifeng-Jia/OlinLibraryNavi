//
//  GraphLoader.swift
//  Navi_json
//
//  Created by Kaifeng Jia on 4/12/26.
//

import Foundation

enum GraphLoadError: Error {
    case fileNotFound
    case decodeFailed(String)
    case invalidData
}

struct GraphLoader {
    static func load() throws -> NavGraph {
        guard let url = Bundle.main.url(forResource: "nav_graph_with_candidates", withExtension: "json") else {
            print("❌ JSON file not found in bundle")
            throw GraphLoadError.fileNotFound
        }
        
        print("✅ Found JSON file at: \(url.path)")
        
        guard let data = try? Data(contentsOf: url) else {
            print("❌ Failed to read data from file")
            throw GraphLoadError.invalidData
        }
        
        print("✅ Loaded \(data.count) bytes of data")
        
        do {
            let graph = try JSONDecoder().decode(NavGraph.self, from: data)
            print("✅ Successfully decoded graph with \(graph.nodes.count) nodes and \(graph.edges.count) edges")
            return graph
        } catch {
            print("❌ JSON decode error: \(error)")
            if let decodingError = error as? DecodingError {
                switch decodingError {
                case .keyNotFound(let key, let context):
                    print("  Missing key: \(key.stringValue) at \(context.codingPath)")
                case .typeMismatch(let type, let context):
                    print("  Type mismatch: expected \(type) at \(context.codingPath)")
                case .valueNotFound(let type, let context):
                    print("  Value not found: \(type) at \(context.codingPath)")
                case .dataCorrupted(let context):
                    print("  Data corrupted at \(context.codingPath)")
                @unknown default:
                    print("  Unknown decoding error")
                }
            }
            throw GraphLoadError.decodeFailed(error.localizedDescription)
        }
    }
    
    static func buildAdjacency(from edges: [Edge]) -> AdjacencyList {
        var adjacency = AdjacencyList()
        for edge in edges {
            adjacency.addEdge(from: edge.source, to: edge.target)
        }
        return adjacency
    }
}
