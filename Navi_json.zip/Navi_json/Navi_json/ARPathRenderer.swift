//
//  ARPathRenderer.swift
//  Navi_json
//
//  Created by Kaifeng Jia on 4/12/26.
//

import SceneKit

struct ARPathRenderer {
    let graph: NavGraph
    let mapper: CoordinateMapper
    let routePath: [String]
    
    private var edgeMap: [String: Edge] = [:]
    
    init(graph: NavGraph, mapper: CoordinateMapper, routePath: [String]) {
        self.graph = graph
        self.mapper = mapper
        self.routePath = routePath
        buildEdgeMap()
    }
    
    private mutating func buildEdgeMap() {
        for edge in graph.edges {
            let key = edgeKey(edge.source, edge.target)
            edgeMap[key] = edge
        }
    }
    
    private func edgeKey(_ from: String, _ to: String) -> String {
        [from, to].sorted().joined(separator: "-")
    }
    
    func renderPath() -> SCNNode {
        let container = SCNNode()
        
        for i in 0..<routePath.count - 1 {
            let segment = createSegment(from: routePath[i], to: routePath[i + 1])
            container.addChildNode(segment)
        }
        
        return container
    }
    
    private func createSegment(from: String, to: String) -> SCNNode {
        let key = edgeKey(from, to)
        
        if let edge = edgeMap[key], let polylineM = edge.polylineM, !polylineM.isEmpty {
            return createPolylineSegment(polylineM)
        }
        
        guard let n1 = graph.nodes.first(where: { $0.id == from }),
              let n2 = graph.nodes.first(where: { $0.id == to }) else {
            return SCNNode()
        }
        
        return createStraightSegment(from: n1, to: n2)
    }
    
    private func createPolylineSegment(_ polylineM: [[Double]]) -> SCNNode {
        let container = SCNNode()
        
        for i in 0..<polylineM.count - 1 {
            let p1 = mapper.toARPosition(meterX: polylineM[i][0], meterY: polylineM[i][1])
            let p2 = mapper.toARPosition(meterX: polylineM[i + 1][0], meterY: polylineM[i + 1][1])
            container.addChildNode(createLine(from: p1, to: p2))
        }
        
        return container
    }
    
    private func createStraightSegment(from n1: Node, to n2: Node) -> SCNNode {
        let p1 = mapper.toARPosition(node: n1)
        let p2 = mapper.toARPosition(node: n2)
        return createLine(from: p1, to: p2)
    }
    
    private func createLine(from p1: SCNVector3, to p2: SCNVector3) -> SCNNode {
        let vector = SCNVector3(p2.x - p1.x, p2.y - p1.y, p2.z - p1.z)
        let length = sqrt(vector.x * vector.x + vector.y * vector.y + vector.z * vector.z)
        
        let cylinder = SCNCylinder(radius: 0.01, height: CGFloat(length))
        cylinder.firstMaterial?.diffuse.contents = UIColor.systemRed
        
        let node = SCNNode(geometry: cylinder)
        node.position = SCNVector3((p1.x + p2.x) / 2, (p1.y + p2.y) / 2, (p1.z + p2.z) / 2)
        node.rotation = rotationBetweenVectors(SCNVector3(0, 1, 0), vector)
        
        return node
    }
    
    private func rotationBetweenVectors(_ v1: SCNVector3, _ v2: SCNVector3) -> SCNVector4 {
        let cross = SCNVector3(
            v1.y * v2.z - v1.z * v2.y,
            v1.z * v2.x - v1.x * v2.z,
            v1.x * v2.y - v1.y * v2.x
        )
        let dot = v1.x * v2.x + v1.y * v2.y + v1.z * v2.z
        let length1 = sqrt(v1.x * v1.x + v1.y * v1.y + v1.z * v1.z)
        let length2 = sqrt(v2.x * v2.x + v2.y * v2.y + v2.z * v2.z)
        let angle = acos(max(-1, min(1, dot / (length1 * length2))))
        
        let crossLength = sqrt(cross.x * cross.x + cross.y * cross.y + cross.z * cross.z)
        if crossLength > 0.0001 {
            return SCNVector4(cross.x / crossLength, cross.y / crossLength, cross.z / crossLength, angle)
        }
        return SCNVector4(0, 1, 0, 0)
    }
}
