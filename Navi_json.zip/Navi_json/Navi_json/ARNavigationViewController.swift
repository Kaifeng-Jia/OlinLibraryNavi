//
//  ARNavigationViewController.swift
//  Navi_json
//
//  Created by Kaifeng Jia on 4/12/26.
//

import UIKit
import ARKit
import SceneKit

class ARNavigationViewController: UIViewController, ARSCNViewDelegate {
    private var sceneView: ARSCNView!
    private var calibrateButton: UIButton!
    private var instructionLabel: UILabel!
    
    private let graph: NavGraph
    private let startNodeID: String
    private let endNodeID: String
    private let routePath: [String]
    
    private var mapper: CoordinateMapper!
    private var contentRootNode: SCNNode!
    private var isCalibrated = false
    
    init(graph: NavGraph, startNodeID: String, endNodeID: String, routePath: [String]) {
        self.graph = graph
        self.startNodeID = startNodeID
        self.endNodeID = endNodeID
        self.routePath = routePath
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) not implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "AR Navigation"
        
        setupSceneView()
        setupUI()
        setupContent()
        startARSession()
    }
    
    private func setupSceneView() {
        sceneView = ARSCNView(frame: view.bounds)
        sceneView.delegate = self
        sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(sceneView)
        
        mapper = CoordinateMapper(graph: graph, startNodeID: startNodeID)
        contentRootNode = SCNNode()
        sceneView.scene.rootNode.addChildNode(contentRootNode)
    }
    
    private func setupUI() {
        instructionLabel = UILabel()
        instructionLabel.text = "Stand at start point facing the first route segment, then tap Calibrate"
        instructionLabel.numberOfLines = 0
        instructionLabel.textAlignment = .center
        instructionLabel.textColor = .white
        instructionLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        instructionLabel.layer.cornerRadius = 8
        instructionLabel.clipsToBounds = true
        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(instructionLabel)
        
        calibrateButton = UIButton(type: .system)
        calibrateButton.setTitle("Calibrate Heading", for: .normal)
        calibrateButton.titleLabel?.font = .boldSystemFont(ofSize: 18)
        calibrateButton.backgroundColor = .systemGreen
        calibrateButton.setTitleColor(.white, for: .normal)
        calibrateButton.layer.cornerRadius = 12
        calibrateButton.translatesAutoresizingMaskIntoConstraints = false
        calibrateButton.addTarget(self, action: #selector(calibrateHeading), for: .touchUpInside)
        view.addSubview(calibrateButton)
        
        NSLayoutConstraint.activate([
            instructionLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            instructionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            instructionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            calibrateButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            calibrateButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            calibrateButton.widthAnchor.constraint(equalToConstant: 220),
            calibrateButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    private func setupContent() {
        addMarker(at: startNodeID, geometry: SCNSphere(radius: 0.1), color: .systemBlue, elevation: 0.1)
        addMarker(at: endNodeID, geometry: SCNBox(width: 0.15, height: 0.15, length: 0.15, chamferRadius: 0), color: .systemRed, elevation: 0.15)
        addRoutePath()
        addTurnArrows()
    }
    
    private func addMarker(at nodeID: String, geometry: SCNGeometry, color: UIColor, elevation: Float) {
        guard let node = graph.nodes.first(where: { $0.id == nodeID }) else { return }
        geometry.firstMaterial?.diffuse.contents = color
        let markerNode = SCNNode(geometry: geometry)
        markerNode.position = mapper.toARPosition(node: node, elevation: elevation)
        contentRootNode.addChildNode(markerNode)
    }
    
    private func addRoutePath() {
        var renderer = ARPathRenderer(graph: graph, mapper: mapper, routePath: routePath)
        let pathNode = renderer.renderPath()
        contentRootNode.addChildNode(pathNode)
    }
    
    private func addTurnArrows() {
        let arrowGenerator = TurnArrowGenerator(graph: graph, mapper: mapper, routePath: routePath)
        let arrows = arrowGenerator.generateArrows()
        arrows.forEach { contentRootNode.addChildNode($0) }
    }
    
    @objc private func calibrateHeading() {
        guard let camera = sceneView.pointOfView,
              routePath.count >= 2,
              let startNode = graph.nodes.first(where: { $0.id == routePath[0] }),
              let nextNode = graph.nodes.first(where: { $0.id == routePath[1] }) else {
            showCalibrationError()
            return
        }
        
        let cameraYaw = camera.eulerAngles.y
        let start = mapper.toARPosition(node: startNode, elevation: 0)
        let next = mapper.toARPosition(node: nextNode, elevation: 0)
        let desiredYaw = atan2(next.x - start.x, next.z - start.z)
        let yawOffset = desiredYaw - cameraYaw
        
        contentRootNode.eulerAngles.y = yawOffset
        
        isCalibrated = true
        calibrateButton.isHidden = true
        instructionLabel.text = "Calibrated! Follow the path and arrows."
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.instructionLabel.isHidden = true
        }
    }
    
    private func showCalibrationError() {
        instructionLabel.text = "Calibration failed. Invalid route data."
        instructionLabel.backgroundColor = UIColor.systemRed.withAlphaComponent(0.8)
    }
    
    private func startARSession() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
}
