//
//  NavGraph.swift
//  Navi_json
//
//  Created by Kaifeng Jia on 4/12/26.
//

import Foundation
import CoreGraphics

struct NavGraph: Decodable {
    let nodes: [Node]
    let edges: [Edge]
    let metersPerPixel: Double
    // Optional top-level metadata (present in JSON, not required by rest of app)
    let imageWidth: Int?
    let imageHeight: Int?
    let originDefinition: String?
    let yAxis: String?

    enum CodingKeys: String, CodingKey {
        case nodes, edges
        case metersPerPixel = "meters_per_pixel"
        case imageWidth = "image_width"
        case imageHeight = "image_height"
        case originDefinition = "origin_definition"
        case yAxis = "y_axis"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.nodes = try container.decode([Node].self, forKey: .nodes)
        self.edges = (try? container.decode([Edge].self, forKey: .edges)) ?? []
        self.metersPerPixel = try container.decode(Double.self, forKey: .metersPerPixel)
        self.imageWidth = try container.decodeIfPresent(Int.self, forKey: .imageWidth)
        self.imageHeight = try container.decodeIfPresent(Int.self, forKey: .imageHeight)
        self.originDefinition = try container.decodeIfPresent(String.self, forKey: .originDefinition)
        self.yAxis = try container.decodeIfPresent(String.self, forKey: .yAxis)
    }
}

struct Node: Decodable {
    let id: String
    let pixelX: Double
    let pixelY: Double
    let meterX: Double
    let meterY: Double
    let type: String?

    enum CodingKeys: String, CodingKey {
        case id
        // New JSON keys
        case xPx = "x_px"
        case yPx = "y_px"
        case xM = "x_m"
        case yM = "y_m"
        case type
        // Legacy JSON keys
        case pixelXLegacy = "pixel_x"
        case pixelYLegacy = "pixel_y"
        case meterXLegacy = "meter_x"
        case meterYLegacy = "meter_y"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        // Decode id as String or Number, then normalize to String
        if let idString = try? container.decode(String.self, forKey: .id) {
            self.id = idString
        } else if let idInt = try? container.decode(Int.self, forKey: .id) {
            self.id = String(idInt)
        } else if let idDouble = try? container.decode(Double.self, forKey: .id) {
            self.id = (idDouble.rounded() == idDouble) ? String(Int(idDouble)) : String(idDouble)
        } else {
            throw DecodingError.typeMismatch(
                String.self,
                DecodingError.Context(
                    codingPath: container.codingPath + [CodingKeys.id],
                    debugDescription: "Expected id to be String or Number"
                )
            )
        }

        // Decode pixelX with compatibility (prefer new keys)
        if let x = try container.decodeIfPresent(Double.self, forKey: .xPx) {
            self.pixelX = x
        } else if let x = try container.decodeIfPresent(Double.self, forKey: .pixelXLegacy) {
            self.pixelX = x
        } else {
            throw DecodingError.keyNotFound(
                CodingKeys.xPx,
                DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Missing x_px or pixel_x")
            )
        }

        // Decode pixelY with compatibility
        if let y = try container.decodeIfPresent(Double.self, forKey: .yPx) {
            self.pixelY = y
        } else if let y = try container.decodeIfPresent(Double.self, forKey: .pixelYLegacy) {
            self.pixelY = y
        } else {
            throw DecodingError.keyNotFound(
                CodingKeys.yPx,
                DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Missing y_px or pixel_y")
            )
        }

        // Decode meterX with compatibility
        if let mx = try container.decodeIfPresent(Double.self, forKey: .xM) {
            self.meterX = mx
        } else if let mx = try container.decodeIfPresent(Double.self, forKey: .meterXLegacy) {
            self.meterX = mx
        } else {
            throw DecodingError.keyNotFound(
                CodingKeys.xM,
                DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Missing x_m or meter_x")
            )
        }

        // Decode meterY with compatibility
        if let my = try container.decodeIfPresent(Double.self, forKey: .yM) {
            self.meterY = my
        } else if let my = try container.decodeIfPresent(Double.self, forKey: .meterYLegacy) {
            self.meterY = my
        } else {
            throw DecodingError.keyNotFound(
                CodingKeys.yM,
                DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Missing y_m or meter_y")
            )
        }

        self.type = try container.decodeIfPresent(String.self, forKey: .type)
    }

    var pixelPoint: CGPoint {
        CGPoint(x: pixelX, y: pixelY)
    }
}

struct Edge: Decodable {
    let source: String
    let target: String
    let polylinePx: [[Double]]?
    let polylineM: [[Double]]?

    enum CodingKeys: String, CodingKey {
        case source, target
        case polylinePx = "polyline_px"
        case from, to
        case polylineM = "polyline_m"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        func decodeStringOrNumber(_ key: CodingKeys) throws -> String {
            if let s = try? container.decode(String.self, forKey: key) { return s }
            if let i = try? container.decode(Int.self, forKey: key) { return String(i) }
            if let d = try? container.decode(Double.self, forKey: key) {
                return d.rounded() == d ? String(Int(d)) : String(d)
            }
            throw DecodingError.typeMismatch(String.self, .init(codingPath: container.codingPath + [key], debugDescription: "Expected String or Number"))
        }

        if let s = try? decodeStringOrNumber(.source) {
            self.source = s
        } else if let s = try? decodeStringOrNumber(.from) {
            self.source = s
        } else {
            throw DecodingError.keyNotFound(
                CodingKeys.source,
                DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Missing source or from key")
            )
        }

        if let t = try? decodeStringOrNumber(.target) {
            self.target = t
        } else if let t = try? decodeStringOrNumber(.to) {
            self.target = t
        } else {
            throw DecodingError.keyNotFound(
                CodingKeys.target,
                DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Missing target or to key")
            )
        }

        self.polylinePx = try container.decodeIfPresent([[Double]].self, forKey: .polylinePx)
        self.polylineM = try container.decodeIfPresent([[Double]].self, forKey: .polylineM)
    }
}

struct AdjacencyList {
    var neighbors: [String: [String]] = [:]
    
    mutating func addEdge(from: String, to: String) {
        neighbors[from, default: []].append(to)
        neighbors[to, default: []].append(from)
    }
}

