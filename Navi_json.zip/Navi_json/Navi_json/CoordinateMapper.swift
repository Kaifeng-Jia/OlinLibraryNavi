//
//  CoordinateMapper.swift
//  Navi_json
//
//  Created by Kaifeng Jia on 4/12/26.
//

import Foundation
import SceneKit

struct CoordinateMapper {
    let graph: NavGraph
    let startNodeID: String
    
    private var originNode: Node {
        graph.nodes.first { $0.id == startNodeID }!
    }
    
    /// Convert floorplan meter coordinates to AR world coordinates
    /// Floorplan Y (down) → AR Z (forward/south)
    /// Floorplan X (right) → AR X (right/east)
    /// AR Y is vertical (up)
    func toARPosition(meterX: Double, meterY: Double, elevation: Float = 0.05) -> SCNVector3 {
        let dx = Float(meterX - originNode.meterX)
        let dz = Float(meterY - originNode.meterY)
        return SCNVector3(dx, elevation, dz)
    }
    
    func toARPosition(node: Node, elevation: Float = 0.05) -> SCNVector3 {
        toARPosition(meterX: node.meterX, meterY: node.meterY, elevation: elevation)
    }
}
