import UIKit

class FloorplanOverlayView: UIView {
    var graph: NavGraph?
    var startNode: String?
    var endNode: String?
    var routePath: [String] = []
    var onRouteChanged: (() -> Void)?
    
    private var edgePolylines: [String: Edge] = [:]
    private let nodeRadius: CGFloat = 6
    private let tapThreshold: CGFloat = 18
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        isUserInteractionEnabled = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) not implemented")
    }
    
    func configure(graph: NavGraph) {
        self.graph = graph
        buildEdgeMap()
        setNeedsDisplay()
    }
    
    private func buildEdgeMap() {
        edgePolylines.removeAll()
        guard let graph = graph else { return }
        for edge in graph.edges {
            edgePolylines[edgeKey(edge.source, edge.target)] = edge
        }
    }
    
    private func edgeKey(_ from: String, _ to: String) -> String {
        [from, to].sorted().joined(separator: "-")
    }
    
    // MARK: - Coordinate mapping
    
    private var imageContentFrame: CGRect {
        guard let graph = graph,
              let imageWidth = graph.imageWidth,
              let imageHeight = graph.imageHeight,
              imageWidth > 0,
              imageHeight > 0 else {
            return bounds
        }
        
        let imageSize = CGSize(width: imageWidth, height: imageHeight)
        let viewSize = bounds.size
        
        let scale = min(viewSize.width / imageSize.width,
                        viewSize.height / imageSize.height)
        
        let scaledWidth = imageSize.width * scale
        let scaledHeight = imageSize.height * scale
        
        let x = (viewSize.width - scaledWidth) / 2.0
        let y = (viewSize.height - scaledHeight) / 2.0
        
        return CGRect(x: x, y: y, width: scaledWidth, height: scaledHeight)
    }
    
    private func screenPoint(for node: Node) -> CGPoint {
        guard let graph = graph,
              let imageWidth = graph.imageWidth,
              let imageHeight = graph.imageHeight else {
            return CGPoint(x: node.pixelX, y: node.pixelY)
        }
        
        let frame = imageContentFrame
        
        let x = frame.minX + CGFloat(node.pixelX / Double(imageWidth)) * frame.width
        let y = frame.minY + CGFloat(node.pixelY / Double(imageHeight)) * frame.height
        
        return CGPoint(x: x, y: y)
    }
    
    private func screenPoint(for pixelPoint: [Double]) -> CGPoint {
        guard let graph = graph,
              let imageWidth = graph.imageWidth,
              let imageHeight = graph.imageHeight,
              pixelPoint.count >= 2 else {
            return .zero
        }
        
        let frame = imageContentFrame
        
        let x = frame.minX + CGFloat(pixelPoint[0] / Double(imageWidth)) * frame.width
        let y = frame.minY + CGFloat(pixelPoint[1] / Double(imageHeight)) * frame.height
        
        return CGPoint(x: x, y: y)
    }
    
    // MARK: - Drawing
    
    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext(), let graph = graph else { return }
        
        drawRoute(ctx)
        drawNodes(ctx, graph: graph)
    }
    
    private func drawRoute(_ ctx: CGContext) {
        guard routePath.count > 1 else { return }
        
        ctx.setStrokeColor(UIColor.systemBlue.cgColor)
        ctx.setLineWidth(3)
        ctx.setLineCap(.round)
        ctx.setLineJoin(.round)
        
        for i in 0..<routePath.count - 1 {
            let key = edgeKey(routePath[i], routePath[i + 1])
            
            if let edge = edgePolylines[key], let polyline = edge.polylinePx, !polyline.isEmpty {
                drawPolyline(ctx, polyline: polyline)
            } else {
                drawStraightLine(ctx, from: routePath[i], to: routePath[i + 1])
            }
        }
    }
    
    private func drawPolyline(_ ctx: CGContext, polyline: [[Double]]) {
        guard !polyline.isEmpty else { return }
        
        ctx.beginPath()
        ctx.move(to: screenPoint(for: polyline[0]))
        for pt in polyline.dropFirst() {
            ctx.addLine(to: screenPoint(for: pt))
        }
        ctx.strokePath()
    }
    
    private func drawStraightLine(_ ctx: CGContext, from: String, to: String) {
        guard let graph = graph,
              let n1 = graph.nodes.first(where: { $0.id == from }),
              let n2 = graph.nodes.first(where: { $0.id == to }) else { return }
        
        ctx.beginPath()
        ctx.move(to: screenPoint(for: n1))
        ctx.addLine(to: screenPoint(for: n2))
        ctx.strokePath()
    }
    
    private func drawNodes(_ ctx: CGContext, graph: NavGraph) {
        for node in graph.nodes {
            let center = screenPoint(for: node)
            let color = nodeColor(for: node.id)
            ctx.setFillColor(color.cgColor)
            
            let rect = CGRect(
                x: center.x - nodeRadius,
                y: center.y - nodeRadius,
                width: nodeRadius * 2,
                height: nodeRadius * 2
            )
            ctx.fillEllipse(in: rect)
        }
    }
    
    private func nodeColor(for id: String) -> UIColor {
        if id == startNode { return .systemGreen }
        if id == endNode { return .systemRed }
        return .systemGray
    }
    
    // MARK: - Touch
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first, graph != nil else { return }
        let point = touch.location(in: self)
        
        if let nearest = nearestNode(to: point) {
            if startNode == nil {
                startNode = nearest.id
                print("Selected start node: \(nearest.id)")
            } else if endNode == nil {
                endNode = nearest.id
                print("Selected end node: \(nearest.id)")
                computePath()
            } else {
                resetAndSetStart(nearest.id)
                print("Reset and selected new start node: \(nearest.id)")
            }
            
            setNeedsDisplay()
            onRouteChanged?()
        } else {
            print("No node hit at point: \(point)")
        }
    }
    
    private func resetAndSetStart(_ id: String) {
        startNode = id
        endNode = nil
        routePath = []
    }
    
    private func nearestNode(to point: CGPoint) -> Node? {
        guard let graph = graph else { return nil }
        
        return graph.nodes
            .map { node in
                let p = screenPoint(for: node)
                let d = hypot(p.x - point.x, p.y - point.y)
                return (node: node, dist: d)
            }
            .filter { $0.dist <= tapThreshold }
            .min(by: { $0.dist < $1.dist })?
            .node
    }
    
    private func computePath() {
        guard let graph = graph, let start = startNode, let end = endNode else { return }
        let adjacency = GraphLoader.buildAdjacency(from: graph.edges)
        let planner = PathPlanner(graph: graph, adjacency: adjacency)
        routePath = planner.findPath(from: start, to: end) ?? []
        print("Computed route path: \(routePath)")
        onRouteChanged?()
    }
}
