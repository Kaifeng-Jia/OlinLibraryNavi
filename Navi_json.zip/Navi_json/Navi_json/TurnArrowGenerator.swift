//
//  TurnArrowGenerator.swift
//  Navi_json
//
//  Created by Kaifeng Jia on 4/12/26.
//

import SceneKit

struct TurnArrowGenerator {
    let graph: NavGraph
    let mapper: CoordinateMapper
    let routePath: [String]
    
    private let turnThreshold: Float = 30.0 // degrees
    private let minSegmentLength: Float = 0.5 // meters
    
    func generateArrows() -> [SCNNode] {
        let segments = buildSegments()
        let filtered = mergeShortSegments(segments)
        let turns = detectTurns(filtered)
        return turns.map { createArrow(at: $0) }
    }
    
    private func buildSegments() -> [RouteSegment] {
        var segments: [RouteSegment] = []
        
        for i in 0..<routePath.count - 1 {
            guard let n1 = graph.nodes.first(where: { $0.id == routePath[i] }),
                  let n2 = graph.nodes.first(where: { $0.id == routePath[i + 1] }) else { continue }
            
            let p1 = mapper.toARPosition(node: n1, elevation: 0)
            let p2 = mapper.toARPosition(node: n2, elevation: 0)
            
            segments.append(RouteSegment(start: p1, end: p2, startNodeID: n1.id, endNodeID: n2.id))
        }
        
        return segments
    }
    
    private func mergeShortSegments(_ segments: [RouteSegment]) -> [RouteSegment] {
        var merged: [RouteSegment] = []
        var current: RouteSegment?
        
        for seg in segments {
            if let curr = current {
                if curr.length < minSegmentLength {
                    current = RouteSegment(start: curr.start, end: seg.end, startNodeID: curr.startNodeID, endNodeID: seg.endNodeID)
                } else {
                    merged.append(curr)
                    current = seg
                }
            } else {
                current = seg
            }
        }
        
        if let final = current {
            merged.append(final)
        }
        
        return merged
    }
    
    private func detectTurns(_ segments: [RouteSegment]) -> [TurnPoint] {
        var turns: [TurnPoint] = []
        
        for i in 0..<segments.count - 1 {
            let incoming = segments[i].direction
            let outgoing = segments[i + 1].direction
            let angle = angleBetween(incoming, outgoing)
            
            if angle >= turnThreshold {
                turns.append(TurnPoint(
                    position: segments[i].end,
                    direction: outgoing,
                    angle: angle
                ))
            }
        }
        
        return turns
    }
    
    private func angleBetween(_ v1: SCNVector3, _ v2: SCNVector3) -> Float {
        let dot = v1.x * v2.x + v1.z * v2.z
        let len1 = sqrt(v1.x * v1.x + v1.z * v1.z)
        let len2 = sqrt(v2.x * v2.x + v2.z * v2.z)
        let cosAngle = dot / (len1 * len2)
        return acos(max(-1, min(1, cosAngle))) * 180.0 / .pi
    }
    
    private func createArrow(at turn: TurnPoint) -> SCNNode {
        let arrow = SCNNode()
        
        // Shaft
        let shaft = SCNCylinder(radius: 0.02, height: 0.3)
        shaft.firstMaterial?.diffuse.contents = UIColor.systemYellow
        let shaftNode = SCNNode(geometry: shaft)
        shaftNode.position = SCNVector3(0, 0.3, 0)
        arrow.addChildNode(shaftNode)
        
        // Head
        let head = SCNCone(topRadius: 0, bottomRadius: 0.08, height: 0.15)
        head.firstMaterial?.diffuse.contents = UIColor.systemYellow
        let headNode = SCNNode(geometry: head)
        headNode.position = SCNVector3(0, 0.525, 0)
        arrow.addChildNode(headNode)
        
        // Position & orient
        arrow.position = SCNVector3(turn.position.x, turn.position.y + 0.15, turn.position.z)
        
        let angle = atan2(turn.direction.x, turn.direction.z)
        arrow.eulerAngles = SCNVector3(0, angle, 0)
        
        return arrow
    }
}

struct RouteSegment {
    let start: SCNVector3
    let end: SCNVector3
    let startNodeID: String
    let endNodeID: String
    
    var direction: SCNVector3 {
        let dx = end.x - start.x
        let dz = end.z - start.z
        let len = sqrt(dx * dx + dz * dz)
        return len > 0 ? SCNVector3(dx / len, 0, dz / len) : SCNVector3(0, 0, 1)
    }
    
    var length: Float {
        let dx = end.x - start.x
        let dz = end.z - start.z
        return sqrt(dx * dx + dz * dz)
    }
}

struct TurnPoint {
    let position: SCNVector3
    let direction: SCNVector3
    let angle: Float
}
